#include <iostream>
using namespace std;
/**
 * 
 * virtual enables dynamic binding

Function call is resolved at runtime

Base class pointer → Derived class object

Without virtual, base class function would execute (compile-time binding)
 */
class Shape {
public:
    virtual void area() {
        cout << "Calculating area of Shape" << endl;
    }
};


class Circle : public Shape {
public:
    void area() {
        cout << "Area of Circle = πr²" << endl;
    }
};
class Rectangle : public Shape {
public:
    void area() {
        cout << "Area of Rectangle = l × b" << endl;
    }
};

int main() {
    Shape* s1;
    Shape* s2;

    Circle c;
    Rectangle r;

    s1 = &c;
    s2 = &r;

    s1->area();   // Calls Circle's area()
    s2->area();   // Calls Rectangle's area()

    return 0;
}