/**
 * Hierarchical Inheritance
 * Multiple children inherit from the same parent.
 */

 #include <iostream>
using namespace std;

class Shape {
public:
    void draw() {
        cout << "Drawing shape\n";
    }
};


class Circle : public Shape {
public:
    void area() {
        cout << "Area of Circle\n";
    }
};

class Rectangle : public Shape {
public:
    void area() {
        cout << "Area of Rectangle\n";
    }
};

int main(){
    Circle c;
    Rectangle r;
    c.draw();
    c.area();

    r.draw();
    r.area();
    cout << "\n";
    return 0;
}