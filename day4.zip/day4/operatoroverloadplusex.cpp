#include <iostream>
using namespace std;

//Complex c3=c1+c2 here Complex is an user defined class
//We are going to overloading the + operator for a user-defined type.

class Complex{

    private:
        int real,imag;
    public:
        Complex(int r=0,int i=0){
            real = r;
            imag = i;
        }

    //Overload + operator
    Complex operator+(Complex const &obj){
        Complex res;
        res.real = real + obj.real;
        res.imag = imag + obj.imag;
        return res;
    }

    void display(){
        cout<<real<<"+"<<imag<<"i"<<endl;
    }


    int main() {
        
    Complex c1(3, 4);
    Complex c2(1, 2);

    Complex c3 = c1 + c2;   // c1.operator+(c2)

    cout << "First Complex: ";
    c1.display();

    cout << "Second Complex: ";
    c2.display();

    cout << "Result: ";
    c3.display();

    return 0;
}
};
