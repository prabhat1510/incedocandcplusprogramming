/**
 * In C++ ,a friend function or friend class is allowed to access private and protected
 * members of another class.
 * This is useful when two classes or a function must closely cooperate while still
 * keeping the data encapsulated.
 * Friendship is granted, not taken.
 * A class decided who its friend is. 
 */

 #include <iostream>
 using namespace std;


 class Box{
    private:
        int length;
    public: 
        //Box(): length(0){}
        Box(int l): length(l){}
        // Declare friend function
        friend void showLength(Box b);
 };

 void showLength(Box b){
    cout<<b.length;
 }

 int main(){
    Box b(10);
    showLength(b);
    return 0;
 }

