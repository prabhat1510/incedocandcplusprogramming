#include <iostream>
using namespace std;

class Animal{
    protected:
    int age;
    void sleep(){
        cout<<"I am sleeping"<<endl;
    }
    
    public:
    void eat(){
        cout<<"I am eating"<<endl;
    }

};

class Dog : public Animal{
    public: 
    void getAge(){
        age=15;
        cout<<"Age is : "<<age<<endl;
    }
    public:
    void bark(){
        cout<<"I am barking"<<endl;
    }
};

int main(){
    Dog d1;
    d1.eat();
    d1.bark();
    d1.getAge();
    return 0;   
}