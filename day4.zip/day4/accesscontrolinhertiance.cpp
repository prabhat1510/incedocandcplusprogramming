/**
 * Access Control in Inheritance
 * When one class inherits from another, the access specifier used in 
 * inheritance (public, protected, or private) controls how the base class 
 * members are accessible in the derived class and outside the class.
 * 
 * | Base Member | In Derived Class | Accessible Outside? |
| ----------- | ---------------- | ------------------- |
| `public`    | public           | Yes                 |
| `protected` | protected        | No                  |
| `private`   | Not accessible   | No                  |

 */


#include <iostream>
using namespace std;

class Base {
public:
    int a = 10;
protected:
    int b = 20;
private:
    int c = 30;
public:
int getC(){
    return c;
}
};
class Derived : public Base{
    public:
    void show(){
        //cout<<a<<" "<<b<<" "<<c; //Error c is not accessible
        cout<<a<<" "<<b<<" "<<endl;
    }
};

int main(){
    Derived d;
  
    d.show();
    cout<<d.a<<" "<<d.getC()<<endl;
    return 0;
}