#include <iostream>
using namespace std;

class Student {
private:
    int roll;
    string name;

public:
    // Friend function declarations
    friend ostream& operator<<(ostream& out, const Student& s);
    friend istream& operator>>(istream& in, Student& s);
};

// Overload << (output)
ostream& operator<<(ostream& out, const Student& s) {
    out << "Name: " << s.name << ", Roll: " << s.roll << endl;
    return out;
}
// Overload >> (input)
istream& operator>>(istream& in, Student& s){
    cout <<"Roll :";
    in >>s.roll;
    cout << "Enter Name: ";
    in >> s.name;
    return in;
}

int main(){
    Student s;
    cin >> s; //uses overloaded >>
    cout << s;//uses overloaded <<
    
    return 0;
}