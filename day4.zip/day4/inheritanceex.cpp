/**
 * Inheritance-- single, mulitple,multilevel and hierarchical
 * It allows a class(child/derived) to acquire the properties and behaviour
 * of another class (parent/base)
 * It promotes code reusability,hierarchical design and models real-world applications      
 * Types: 1. Single 2. Multiple 3. Multilevel 4. Hierarchical
 * 
 */
class Parent{
    //properties and functions
    //access specifier - public --- will be accessible in derived class
    //access specifier - private -- not directly accessible
    //access specifier - protected -- accessible in derived class
};

class Child : public Parent{
    //acquires all properties and functions of parent class
    //can have its own properties and functions
};