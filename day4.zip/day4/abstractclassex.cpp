/**
 * An Abstract class is that:
 * Cannot be instantiated
 * Exist to be inherited
 * Contains at least one pure virtual function
 * 
 */
#include <iostream>
using namespace std;

class Shape{
    public:
     virtual void area()=0;//Pure Virtual Function
     void display(){
        cout<<"Display from Shape class" << endl;
     }
}; //This makes Shape class as an abstract class

class Circle : public Shape {
public:
    void area() {
        cout << "Area of Circle = πr²" << endl;
    }
};

class Rectangle : public Shape {
public:
    void area() {
        cout << "Area of Rectangle = l*b" << endl;
    }
};

int main() {
    Shape* s;

    Circle c;
    Rectangle r;

    s = &c;
    s->area();

    s = &r;
    s->area();
    s->display();
    return 0;
}



