/**
 * Multilevel Inheritance
 * A class is derived from another derived class.
 * 
 */
#include <iostream>
using namespace std;

class Vehicle {
public:
    void start() {
        cout << "Vehicle starts\n";
    }
};

class Car : public Vehicle {
public:
    void accelerate() {
        cout << "Car accelerates\n";
    }
};

class ElectricCar : public Car{
    public:
        void charge(){
            cout<<"Electric Car charging\n";
        }
};

int main(){
    ElectricCar e;
    e.start();
    e.accelerate();
    e.charge();
    return 0;
}