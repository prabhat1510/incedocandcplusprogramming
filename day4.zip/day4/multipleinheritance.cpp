/**
 * Multiple Inheritance
 * One child will inherit from more than one parent
 */

#include<iostream>
using namespace std;

class Printer{
    public:
    void print(){
        cout<<"I am printer"<<endl;
    }
 
 };
class Scanner{
    public:
    void scan(){
        cout<<"I am scanner"<<endl;
    }
};

 class AllInOne : public Printer, public Scanner{
    void hello(){
        cout<<"hello"<<endl;
    }
    public:
    void printScan(){
        cout<<"I am print scan"<<endl;
    }
};

int main(){
    AllInOne device;
    device.print();
    device.scan();
    device.printScan();
    return 0;
}