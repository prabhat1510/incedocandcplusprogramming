#include <iostream>
using namespace std;

class Employee{
    private:
     int empId;
     string empName;
    public:
    Employee(){
        cout<<"Default Constructor"<<endl;
        empId=0;
        empName=" ";
    } 
    //Accessor Methods
    int getEmpId(){
        return empId;
    }
    void setEmpId(int eId){
        empId=eId;
    }

    string getEmpName(){
        return empName;       
    }

    void setEmpName(string eName){
        empName=eName;
    }

};

class Manager : public Employee{
    private:
     string deptName;

    public:
    
    Manager(){
        cout<<"Manager Default Constructor"<<endl;
        deptName="IT";
    }
    string getDeptName(){
        return deptName;
    }
};

int main(){
    Manager m1;
    cout<<m1.getEmpId();
    m1.setEmpId(101);
    m1.setEmpName("John");
    cout<<m1.getEmpId()<<endl;
    cout<<m1.getEmpName()<<endl;
    cout<<m1.getDeptName();
    cout<<sizeof(m1);
    cout<<m1.Employee::getEmpId();
    cout<<m1.Employee::getEmpName();
    return 0;
}