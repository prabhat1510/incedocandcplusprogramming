#include <iostream>
using namespace std;

class Account{
    public :
     virtual void calculateInterest(){
            cout<<"interest calculation of account"<<endl;
        } 
      
};

class SavingsAccount : public Account{
    public :
    void calculateInterest(){
            cout<<"interest calculation of savingsaccount"<<endl;
        }
};

class CurrentAccount : public Account{
    public :
    void calculateInterest(){
            cout<<"interest calculation of currentaccount"<<endl;
        }
};  

int main(){
    Account* acc;
    SavingsAccount sa;
    CurrentAccount ca;
    
    acc=&sa;
    acc->calculateInterest();
    acc=&ca;
    acc->calculateInterest();
    
    return 0;
}