/**
 * Polymorphism in C++ – Function Overriding
When we teach Polymorphism, we are teaching the idea of “one interface, many behaviors.”
In C++, this is most commonly achieved using inheritance + function overriding
 + virtual functions.

Function Overriding happens when:

A derived (child) class provides its own implementation of a function that already 
exists in the base (parent) class.

The function signatures must be the same (name, return type, parameters).

This allows the same function call to behave differently based on the object type at
 runtime.
 */

#include <iostream>
using namespace std;    

class Animal{
    public:
        virtual void speak(){//virtual tells compiler decide which function to call at runtime based on the object type, not the pointer type
            cout<<"Animal makes some generic sound"<<endl;
        }
};
class Dog: public Animal{
    public:
        void speak(){//Override speak of Animal
            cout<<"Dog barks: Woof! Woof!"<<endl;
        }
};

int main(){

    Animal* a; //Here pointer type is Animal
    //a->speak();
    Dog d1;
    //a.speak(); //Animal makes a sound
    a=&d1;//Object type is Dog , because speak() is a virtual , C++ calls Dog's speak()
   // d1.speak();//Dog barks
   a->speak();
    return 0;
}