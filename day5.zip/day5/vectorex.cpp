/**
In C++, a vector is a dynamic array provided by the Standard Template Library (STL).
Unlike normal arrays, vectors:
Grow and shrink automatically
Know their own size
Provide many built-in operations
Are safer and more flexible than raw arrays
 */
#include <iostream>
#include <vector>
using namespace std;

int main()
{
    // Declare a vector of integers
    vector<int> numbers;

    // Add elements to the vector
    numbers.push_back(10);
    numbers.push_back(20);
    numbers.push_back(30);

    // Access elements
    cout << "First element: " << numbers[0] << endl;
    cout << "Second element: " << numbers[1] << endl;
    cout << "Third element: " << numbers[2] << endl;

    // Get the size of the vector
    cout << "Size of vector: " << numbers.size() << endl;

    return 0;
}
