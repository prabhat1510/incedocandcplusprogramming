/**
Templates in C++ allow you to write generic code—code 
that works with any data type without rewriting it 
for int, float, double, string, etc.

Think of templates as:

“A blueprint for generating functions or classes for 
different data types at compile time.”

There are two main types:

Function Templates
Class Templates
*/

/**
 * 
 * Function Templates
 * A function template defines a generic function.
 */
//Without Template (Problem) -- Multiple versions we will have to write
/*
int add(int a, int b) {
    return a + b;
}

float add(float a, float b) {
    return a + b;
}
*/

//With Function Template
#include <iostream>
using namespace std;

template <typename T> // T is a placeholder for a type
T add(T a, T b){
    return a+b;
}

int main(){
    cout << add(10,20) << endl; //int
    cout << add(1.5,2.5) << endl; //double
    cout << add(1.20f,2.3f) << endl; //float
    return 0;
}