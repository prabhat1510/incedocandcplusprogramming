#include <iostream>
#include <fstream>
using namespace std;

int main(){
    fstream file("employee.txt",ios::in | ios::out | ios::app);
    if(!file){
        cout << "File open failed "<< endl;
        return 1;
    }
    //Write to a file
    file << "201 Rahul\n";
    file << "202 Raju\n";

    //Move read pointer to begining
    file.seekg(0);

    int id;
    string name;
    cout<< "Employee Records:\n";

    while(file >> id >> name){
        cout << id <<" "<< name<< endl;
    }
    file.close();
    return 0;
}
