#include <iostream>
#include <vector>
using namespace std;

int main(){
    vector<int> v; //empty vector
    //Add elements
    v.push_back(15);
    v.push_back(42);
    v.push_back(51);
    v.push_back(25);
    v.push_back(10);

    cout << "Initial Vector: ";
    for (int x : v)
        cout << x << " ";
    cout << endl;

    cout << "Another Vector: ";
    for(int i=0;i<v.size();i++){
        cout << v[i] << " "; 
    }
    cout << endl;

      // Access elements
    cout << "First element: " << v[0] << endl;
    cout << "Second element using at(): " << v.at(1) << endl;

    cout << "Using at() Vector: ";
    for(int i=0;i<v.size();i++){
        cout << v.at(i) << " "; 
    }
    cout << endl;

    //Insert element at position 1
    v.insert(v.begin() + 1 ,11);
    cout << "After Insert: ";
    for (int x : v)
        cout << x << " ";
    cout << endl;

     // Remove last element
    v.pop_back();

    cout << "After Pop: ";
    for (int x : v)
        cout << x << " ";
    cout << endl;

     // Erase element at index 1
    v.erase(v.begin() + 1);

    cout << "After Erase: ";
    for (int x : v)
        cout << x << " ";
    cout << endl;

    // Size and empty check
    cout << "Size of vector: " << v.size() << endl;
    cout << "Is vector empty? " << (v.empty() ? "Yes" : "No") << endl;
    
    // Clear all elements
    v.clear();
    cout << "After Clear, Size: " << v.size() << endl;
    return 0;
}