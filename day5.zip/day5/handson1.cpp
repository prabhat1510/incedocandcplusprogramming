//Create a generic Stack class using templates
#include <iostream>
#include <stdexcept>
using namespace std;

template <typename T>
class Stack {
private:
    T* arr;
    int top;
    int capacity;

public:
    // Constructor
    Stack(int size = 10) {
        capacity = size;
        arr = new T[capacity];
        top = -1;
    }

    // Push element onto stack
    void push(const T& value) {
        if (top == capacity - 1) {
            throw overflow_error("Stack Overflow");
        }
        arr[++top] = value;
    }

    // Pop element from stack
    T pop() {
        if (top == -1) {
            throw underflow_error("Stack Underflow");
        }
        return arr[top--];
    }

    // Peek top element
    T peek() const {
        if (top == -1) {
            throw underflow_error("Stack is Empty");
        }
        return arr[top];
    }

    // Check if stack is empty
    bool isEmpty() const {
        return top == -1;
    }

    // Destructor
    ~Stack() {
        delete[] arr;
    }
};

int main() {
    try {
        // Stack of integers
        Stack<int> intStack(5);
        intStack.push(10);
        intStack.push(20);
        intStack.push(30);

        cout << "Top of intStack: " << intStack.peek() << endl;
        cout << "Popped: " << intStack.pop() << endl;
        cout << "Popped: " << intStack.pop() << endl;

        // Stack of strings
        Stack<string> strStack(3);
        strStack.push("C++");
        strStack.push("Templates");
        strStack.push("Stack");

        cout << "\nTop of strStack: " << strStack.peek() << endl;
        while (!strStack.isEmpty()) {
            cout << "Popped: " << strStack.pop() << endl;
        }
    }
    catch (exception& e) {
        cout << "Error: " << e.what() << endl;
    }

    return 0;
}



