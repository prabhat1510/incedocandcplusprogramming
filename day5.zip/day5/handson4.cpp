//5.	Create a word frequency counter using maps

#include <iostream>
#include <map>
#include <sstream>
#include <cctype>
using namespace std;

// Convert a word to lowercase and remove punctuation
string normalize(const string& word) {
    string clean;
    for (char ch : word) {
        if (isalnum(static_cast<unsigned char>(ch))) {
            clean += tolower(ch);
        }
    }
    return clean;
}

int main() {
    map<string, int> wordCount;
    string line;

    cout << "Enter a sentence:\n";
    getline(cin, line);

    stringstream ss(line);
    string word;

    while (ss >> word) {
        word = normalize(word);
        if (!word.empty()) {
            wordCount[word]++;
        }
    }

    cout << "\nWord Frequency:\n";
    cout << "----------------\n";
    for (const auto& pair : wordCount) {
        cout << pair.first << " : " << pair.second << endl;
    }

    return 0;
}
