/**File handling in C++ allows your program to store data permanently in files and retrieve it later.
C++ provides three main stream classes from <fstream>:

Class	    Purpose
ofstream	Write data to a file
ifstream	Read data from a file
fstream	    Read and write to a file


Common File Modes
Mode	Meaning
ios::in	Read mode
ios::out	Write mode
ios::app	Append (add at end)
ios::trunc	Clear existing content
ios::binary	Binary file mode
**/

//Writing to a File using ofstream

#include <iostream>
#include <fstream>
using namespace std;

int main(){
    ofstream fout("students.txt",ios::out | ios::app); //Opening file for writing

    if(!fout){
        cout << "File creation failed"<<endl;
        return 1;
    }

    fout << "101 Sushant \n";
    fout << "102 Vanshika \n";
    fout << "103 Sharma Jee \n";
    fout << "104 Gupta Jee \n";
    //fout << "105 Yugan Dhar \n";

    fout.close(); //close the file
    cout << "Data written to file successfully."<<endl;
    return 0;
}
