//Class Template
#include <iostream>
using namespace std;

template <class T>
class Box{
    private:
     T value;
    public:
        Box(T v){
            value=v;
        }
        T getValue(){
            return value;
        }

};

int main(){
    Box<int> b1(100);
    Box<float> b2(3.14f);
    Box<string> b3("C++ Templates");

    cout << b1.getValue() << endl;
    cout << b2.getValue() << endl;
    cout << b3.getValue() << endl;

    return 0;
}