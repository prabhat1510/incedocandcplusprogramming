#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

int main(){
    ifstream fin("students.txt"); //open file for reading
    if(!fin){
        cout << "File not found "<<endl;
        return 1;
    }
    string line;
    //int roll;
    //string name;
    cout << "Student Records:\n";
    /**while(fin >> roll >> name){
        cout << roll <<" "<< name << endl;
    }**/
   //Use getline() to read each complete line and then extract data.
    while (getline(fin, line)) {
        if (line.empty()) continue; // skip empty lines

        int roll;
        string name;

        stringstream ss(line);
        ss >> roll;              // read roll number
        getline(ss, name);       // read remaining as full name

        // remove leading space from name if present
        if (!name.empty() && name[0] == ' ')
            name.erase(0, 1);

        cout << roll << " " << name << endl;
    }

    fin.close();
    return 0;
}