//3.	Build a student management system with exception handling
#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;

class Student {
public:
    int id;
    string name;
    int age;

    Student(int i, string n, int a) : id(i), name(n), age(a) {
        if (age <= 0)
            throw invalid_argument("Age must be positive");
    }
};

class StudentManager {
private:
    vector<Student> students;

public:
    void addStudent(int id, string name, int age) {
        for (auto& s : students) {
            if (s.id == id)
                throw runtime_error("Student with this ID already exists");
        }
        students.emplace_back(id, name, age);
    }

    void displayAll() const {
        if (students.empty())
            throw runtime_error("No students available");

        cout << "\nID\tName\tAge\n";
        for (const auto& s : students) {
            cout << s.id << "\t" << s.name << "\t" << s.age << endl;
        }
    }

    Student findStudent(int id) const {
        for (const auto& s : students) {
            if (s.id == id)
                return s;
        }
        throw runtime_error("Student not found");
    }

    void removeStudent(int id) {
        for (auto it = students.begin(); it != students.end(); ++it) {
            if (it->id == id) {
                students.erase(it);
                return;
            }
        }
        throw runtime_error("Cannot delete: Student not found");
    }
};

int main() {
    StudentManager manager;
    int choice;

    while (true) {
        cout << "\n1. Add Student\n2. Display All\n3. Search Student\n4. Remove Student\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        try {
            if (choice == 1) {
                int id, age;
                string name;
                cout << "Enter ID, Name, Age: ";
                cin >> id >> name >> age;
                manager.addStudent(id, name, age);
                cout << "Student added successfully\n";
            }
            else if (choice == 2) {
                manager.displayAll();
            }
            else if (choice == 3) {
                int id;
                cout << "Enter ID to search: ";
                cin >> id;
                Student s = manager.findStudent(id);
                cout << "Found: " << s.id << " " << s.name << " " << s.age << endl;
            }
            else if (choice == 4) {
                int id;
                cout << "Enter ID to remove: ";
                cin >> id;
                manager.removeStudent(id);
                cout << "Student removed successfully\n";
            }
            else if (choice == 5) {
                break;
            }
            else {
                throw invalid_argument("Invalid menu choice");
            }
        }
        catch (exception& e) {
            cout << "Error: " << e.what() << endl;
        }
    }

    return 0;
}
