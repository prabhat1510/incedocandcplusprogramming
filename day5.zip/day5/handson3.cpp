//4.	Use vectors to implement a dynamic contact list
#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Contact {
public:
    string name;
    string phone;
    string email;

    Contact(string n, string p, string e) : name(n), phone(p), email(e) {}
};

class ContactManager {
private:
    vector<Contact> contacts;

public:
    void addContact(const string& name, const string& phone, const string& email) {
        contacts.emplace_back(name, phone, email);
    }

    void displayAll() const {
        if (contacts.empty()) {
            cout << "No contacts available.\n";
            return;
        }

        cout << "\nName\t\tPhone\t\tEmail\n";
        cout << "---------------------------------------------\n";
        for (const auto& c : contacts) {
            cout << c.name << "\t" << c.phone << "\t" << c.email << endl;
        }
    }

    void searchByName(const string& name) const {
        for (const auto& c : contacts) {
            if (c.name == name) {
                cout << "Found: " << c.name << ", " << c.phone << ", " << c.email << endl;
                return;
            }
        }
        cout << "Contact not found.\n";
    }

    void deleteByName(const string& name) {
        for (auto it = contacts.begin(); it != contacts.end(); ++it) {
            if (it->name == name) {
                contacts.erase(it);
                cout << "Contact deleted.\n";
                return;
            }
        }
        cout << "Contact not found.\n";
    }
};

int main() {
    ContactManager manager;
    int choice;

    while (true) {
        cout << "\n1. Add Contact\n2. Display All\n3. Search by Name\n4. Delete by Name\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            string name, phone, email;
            cout << "Enter Name Phone Email: ";
            cin >> name >> phone >> email;
            manager.addContact(name, phone, email);
            cout << "Contact added.\n";
        }
        else if (choice == 2) {
            manager.displayAll();
        }
        else if (choice == 3) {
            string name;
            cout << "Enter name to search: ";
            cin >> name;
            manager.searchByName(name);
        }
        else if (choice == 4) {
            string name;
            cout << "Enter name to delete: ";
            cin >> name;
            manager.deleteByName(name);
        }
        else if (choice == 5) {
            break;
        }
        else {
            cout << "Invalid choice.\n";
        }
    }

    return 0;
}
