//STL is a library that consist of different data structures and 
//algorithms to effectively store and manipulate data.

#include <iostream>
#include <vector>
using namespace std;

int main(){
    // Create a vector called cars that will store strings
  vector<string> cars = {"Volvo", "BMW", "Ford", "Mazda"};

  // Print vector elements
  for (string car : cars) {
    cout << car << "\n";
  }
  cout << car[0] <<endl;
  // Get the first element
  cout << cars.front();

 // Get the last element
 cout << cars.back();

 // Get the second element
cout << cars.at(1);

// Get the third element
cout << cars.at(2);
  return 0;
}