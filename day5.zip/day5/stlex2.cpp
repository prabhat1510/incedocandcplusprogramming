//STL is a library that consist of different data structures and 
//algorithms to effectively store and manipulate data.

#include <iostream>
#include <list>
#include <iterator>
using namespace std;

int main(){
    // Create a list called cars that will store strings
  list<string> cars = {"Volvo", "BMW", "Ford", "Mazda"};

  // Print list elements
  for (string car : cars) {
    cout << car << "\n";
  }
  // Get the first element
  cout << cars.front();

 // Get the last element
 cout << cars.back();

 cars.front()="Honda";
 cars.back()="Suzuki";
  // Get the first element
  cout << cars.front() << "\n";

 // Get the last element
 cout << cars.back();

 // Add an element at the beginning
cars.push_front("Tesla");

// Add an element at the end
cars.push_back("VW");
//cout << cars[2] <<endl;
 cout<< "*****Before insert******"<<endl;
  // Print list elements
  for (string car : cars) {
    cout << car << "\n";
  }
auto it = next(cars.begin());
cars.insert(it,1,"KIA");
  cout<< "******After insert*****"<<endl;
  // Print list elements
  for (string car : cars) {
    cout << car << "\n";
  }

  /**
   * insert(pos_iter, ele_num, ele)
      Parameters: This function takes in three parameters:
pos_iter: Position in the container where the new elements are inserted.
ele_num: Number of elements to insert. Each element is initialized to a copy of val.
ele: Value to be copied (or moved) to the inserted elements.
   */
 list<int> list1 = {1, 5};
 list<int> list2 = {2, 3, 4};

    auto it = next(list1.begin());   // iterator from list1

    list1.insert(it, list2.begin(), list2.end());  // OK

    for (int x : list1)
        cout << x << " ";
return 0;
}