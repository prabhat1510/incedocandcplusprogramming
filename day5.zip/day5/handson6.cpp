//7.	Sort custom objects (Student class) using STL sort with custom comparator
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Student {
public:
    int id;
    string name;
    int marks;

    Student(int i, string n, int m) : id(i), name(n), marks(m) {}
};

// Comparator: Sort by marks (descending)
bool sortByMarks(const Student& a, const Student& b) {
    return a.marks > b.marks;   // higher marks first
}

// Comparator: Sort by name (ascending)
bool sortByName(const Student& a, const Student& b) {
    return a.name < b.name;     // alphabetical order
}

void display(const vector<Student>& students) {
    for (const auto& s : students) {
        cout << s.id << "  " << s.name << "  " << s.marks << endl;
    }
    cout << "----------------------\n";
}

int main() {
    vector<Student> students = {
        {101, "Ravi", 85},
        {102, "Amit", 92},
        {103, "Neha", 78},
        {104, "Kiran", 90}
    };

    cout << "Original List:\n";
    display(students);

    // Sort by marks
    sort(students.begin(), students.end(), sortByMarks);
    cout << "Sorted by Marks (Descending):\n";
    display(students);

    // Sort by name
    sort(students.begin(), students.end(), sortByName);
    cout << "Sorted by Name (Ascending):\n";
    display(students);

    return 0;
}
