//6.	Implement a to-do list application using STL containers
#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Task {
public:
    string title;
    bool completed;

    Task(const string& t) : title(t), completed(false) {}
};

class TodoList {
private:
    vector<Task> tasks;

public:
    void addTask(const string& title) {
        tasks.emplace_back(title);
        cout << "Task added.\n";
    }

    void viewTasks() const {
        if (tasks.empty()) {
            cout << "No tasks available.\n";
            return;
        }

        cout << "\nTo-Do List:\n";
        for (size_t i = 0; i < tasks.size(); ++i) {
            cout << i + 1 << ". "
                 << (tasks[i].completed ? "[Done] " : "[Pending] ")
                 << tasks[i].title << endl;
        }
    }

    void markCompleted(size_t index) {
        if (index == 0 || index > tasks.size()) {
            cout << "Invalid task number.\n";
            return;
        }
        tasks[index - 1].completed = true;
        cout << "Task marked as completed.\n";
    }

    void deleteTask(size_t index) {
        if (index == 0 || index > tasks.size()) {
            cout << "Invalid task number.\n";
            return;
        }
        tasks.erase(tasks.begin() + (index - 1));
        cout << "Task deleted.\n";
    }
};

int main() {
    TodoList todo;
    int choice;

    while (true) {
        cout << "\n1. Add Task\n2. View Tasks\n3. Mark Task Completed\n4. Delete Task\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            string title;
            cout << "Enter task: ";
            getline(cin, title);
            todo.addTask(title);
        }
        else if (choice == 2) {
            todo.viewTasks();
        }
        else if (choice == 3) {
            size_t n;
            cout << "Enter task number: ";
            cin >> n;
            todo.markCompleted(n);
        }
        else if (choice == 4) {
            size_t n;
            cout << "Enter task number: ";
            cin >> n;
            todo.deleteTask(n);
        }
        else if (choice == 5) {
            break;
        }
        else {
            cout << "Invalid choice.\n";
        }
    }

    return 0;
}
