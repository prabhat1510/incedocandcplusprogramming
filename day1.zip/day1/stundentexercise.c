//Write a C program which stores 5 Student Names and Print Them
#include <stdio.h>
#include <string.h>

int main(){
    char names[5][50];
    int i;
    printf("Enter names of 5 students:\n");
    for (i = 0; i < 5; i++) {
        scanf("%s", names[i]);
    }

    printf("\nStudent Names:\n");
    for (i = 0; i < 5; i++) {
        printf("%s\n", names[i]);
    }

    return 0;
}