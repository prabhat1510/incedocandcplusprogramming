#include <stdio.h>

int main() {
    //Logical Operator
    /**
     * && || !
     * and or not
     * 
     */
    printf("%d\n", (5>3) && (10<20));
    printf("%d\n", (5<3) || (10>20));
    printf("%d\n", !(5>3));
    printf("******************************");
    //Bitwise Operators
    printf("%d\n", 5&3);// 0101 & 0011 = 0001 
    printf("%d\n", 5|3);// 0101 | 0011 = 0111
    printf("%d\n", 5^3);// 0101 ^ 0011 = 0110
    printf("%d\n", ~5);// ~ 0101
    return 0;
}