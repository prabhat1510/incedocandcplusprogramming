//1.	Write a program to swap two numbers without using a third variable
#include <stdio.h>

int main() {
    int a = 10, b = 20;

    printf("Before Swap: a = %d, b = %d\n", a, b);

    a = a + b;
    b = a - b;
    a = a - b;

    printf("After Swap:  a = %d, b = %d\n", a, b);

    return 0;
}
//Method 2: Using XOR (Bitwise Safe)
/**
#include <stdio.h>

int main() {
    int a = 10, b = 20;

    printf("Before Swap: a = %d, b = %d\n", a, b);

    a = a ^ b;
    b = a ^ b;
    a = a ^ b;

    printf("After Swap:  a = %d, b = %d\n", a, b);

    return 0;
} */
