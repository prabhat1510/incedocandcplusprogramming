//Write a C program to print numbers from 100 to 1
#include <stdio.h>

int main() {
    int i;

    for (i = 100; i >= 1; i--) {
        printf("%d\n", i);
    }

/** int i = 100;
while (i >= 1) {
    printf("%d\n", i);
    i--;
} */   

    return 0;
}
