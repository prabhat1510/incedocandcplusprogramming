
#include <stdio.h>
#include <string.h>

int main(){
    char str1[20] = "Hello";
    char str2[20] = "World";
     printf("Comparison of str1 and str2: %d\n", strcmp(str1, str2));
     return 0;
}