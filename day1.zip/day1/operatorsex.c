#include <stdio.h>
#include <stdbool.h>

int main() {
    int num1=15;
    int num2=10;

    int res=num1+num2;
    printf("Sum is %d",res);
    res=num1-num2;
    printf("Difference is %d", res);
    res=num1*num2;
    printf("Product is %d", res);
    res=num1/num2;
    printf("Quotient is %d", res);
    res=num1%num2;
    printf("Remainder is %d",res);
    printf("num1++=%d", num1++);
    printf("num1--=%d", num1--);
    printf("num1=%d",num1);
    printf("++num1=%d", ++num1);           
    //Relational Operator
    /**
     * 
     * Multiple line comments
     */
    //bool result=num1>num2;
    printf("num1>num2 is %d", (bool)(num1>num2));
    int result = num1>num2;
    if(result){
        printf("True");
    }else{
        printf("Else");
    }
    (num1>num2)?printf("True"):printf("False");

    //Boolean Data types
    bool t=true;
    bool f=false;
    printf("*****************************");
    printf("True: %d \n",t);
    printf("False: %d", f);
    printf("num1==num2 is %d", (bool)(num1==num2));

    
    return 0;
}