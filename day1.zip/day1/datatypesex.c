#include <stdio.h>

int main() {
    /**printf("Hello,How are you?\\n");*/
    printf("Size of int %ld\\n", sizeof(int));
    printf("Size of char %ld\\n", sizeof(char));
    printf("Size of float %ld\\n", sizeof(float));
    printf("Size of double %ld\\n", sizeof(double));
    printf("Size of short %ld\\n", sizeof(short));
    printf("Size of long %ld\\n", sizeof(long));

    int num1=15;// Declaring and initializing the variable num1 of integer type
    printf("num1 = %d\\n", num1);
    int x;
    x=10;
    printf("x = %d\\n", x);
    float salary = 15000.50;
    double compSal = 200000.50;
    printf("salary = %.2f\\n compSalary = %.2f\\n", salary, compSal);
    char char1='A';
    char char2;
    char2='a';
    printf("char1 = %c\\n char2 = %c\\n", char1, char2);
    int num2;
    printf("Enter number\\n");
    scanf("%d", &num2);
    printf("You entered %d\\n", num2);
    return 0;
}