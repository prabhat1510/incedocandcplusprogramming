#include <stdio.h>

int main() {
    int arr[10];
    int i;

    printf("Enter 10 integers:\n");

    // Input values
    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }

    printf("\nEven numbers in the array are:\n");

    // Print only even numbers
    for (i = 0; i < 10; i++) {
        if (arr[i] % 2 == 0) {
            printf("%d ", arr[i]);
        }
    }

    return 0;
}