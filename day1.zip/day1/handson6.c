//2. Create a calculator with basic operations using switch-case using C program
#include <stdio.h>

int main() {
    char op;
    float num1, num2, result;

    printf("Simple Calculator\n");
    printf("Choose an operation (+, -, *, /): ");
    scanf(" %c", &op);   // space before %c handles newline

    printf("Enter two numbers: ");
    scanf("%f %f", &num1, &num2);

    switch (op) {
        case '+':
            result = num1 + num2;
            break;

        case '-':
            result = num1 - num2;
            break;

        case '*':
            result = num1 * num2;
            break;

        case '/':
            if (num2 != 0)
                result = num1 / num2;
            else {
                printf("Error: Division by zero!\n");
                return 0;
            }
            break;

        default:
            printf("Invalid operator!\n");
            return 0;
    }

    printf("Result: %.2f\n", result);
    return 0;
}
