#include <stdio.h>

int main(){
    int count=0;
    while(count<10){
         printf("Hello World\n");
         count++;
    }

    printf("\n************************\n");
    for(int i=0;i<10;i++){
        printf("Hi \n");
    }
    
    printf("\n************************\n");
    int x=0;
    do
    {
        printf("Hey\n");
        x++;
    } while (x<5);
    
    return 0;
}