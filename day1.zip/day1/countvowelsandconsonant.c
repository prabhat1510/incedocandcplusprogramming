//Write a C program to accept a String and Count Number of Vowels and Consonants in the string

#include <stdio.h>
#include <string.h>

int main()
{
    char str[100];
    int i, vcount, ccount;

    printf("Enter a String : ");
    gets(str);

    for(i=0; str[i]!='\0'; i++)
    {
        if(str[i]=='a'||str[i]=='e'||str[i]=='i'||str[i]=='o'||str[i]=='u'||
           str[i]=='A'||str[i]=='E'||str[i]=='I'||str[i]=='O'||str[i]=='U')
            vcount++;
        else
            ccount++;
    }

    printf("Number of Vowels = %d\n", vcount);
    printf("Number of Consonants = %d\n", ccount);

    return 0;
}