//In C programming Array of Characters is a String and ends with '\0'

#include <stdio.h>
#include <string.h>

int main(){
    char name[10]="Sushant"; 
    printf("%s",name);
    char names[] = "Prabhat";
    //P r a b h a t \0
    printf("\n%s", names);

    printf("***********************************");
    char str1[20] = "Hello";
    char str2[20] = "World";

    printf("Length of str1 = %lu\n", strlen(str1));
    printf("Copy str1 to str2\n");
    strcpy(str2, str1);
    printf("str2 = %s\n", str2);
    strcat(str1," World");
    printf("After concatenation, s1: %s\n", str1);
    printf("str1 = %s\n",str1);
    printf("str2 = %s\n",str2);
    printf("Comparison of str1 and str2: %d\n", strcmp(str1, str2));

    return 0;
}