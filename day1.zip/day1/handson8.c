//4.	Check if a number is prime using functions
#include <stdio.h>

int isPrime(int num) {
    int i;

    if (num <= 1)
        return 0;   // Not prime

    for (i = 2; i <= num / 2; i++) {
        if (num % i == 0)
            return 0;   // Not prime
    }

    return 1;   // Prime
}

int main() {
    int n;

    printf("Enter a number: ");
    scanf("%d", &n);

    if (isPrime(n))
        printf("%d is a Prime number\n", n);
    else
        printf("%d is Not a Prime number\n", n);

    return 0;
}
