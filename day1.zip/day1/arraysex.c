//One dimensional array
#include <stdio.h>

int main() { //   0   1  2  3
    int marks[4]={23,45,67,89}; //Declaration and Initialization

    int studentMarks[5]; //Declaration
    studentMarks[0]=60;
    studentMarks[1]=70;
    studentMarks[2]=80;
    studentMarks[3]=90;
    studentMarks[4]=100;
    //studentMarks[5]=111;//Invalid- out of bound
    for(int i=0;i<5;i++){
        printf("The value of marks %d is %d\n",i,studentMarks[i]);
    }
    printf("size of %d ",sizeof(studentMarks));
    return 0;
}