//Write a C program to Compare Two Strings Without Using strcmp()
//Write a C program to Reverse a String Using Loop
#include <stdio.h>

int main() {
    char s1[100], s2[100];
    int i = 0, flag = 1;

    printf("Enter first string: ");
    gets(s1);

    printf("Enter second string: ");
    gets(s2);

    while (s1[i] != '\0' || s2[i] != '\0') {
        if (s1[i] != s2[i]) {
            flag = 0;
            break;
        }
        i++;
    }

    if (flag)
        printf("Strings are equal\n");
    else
        printf("Strings are not equal\n");

    return 0;
}

//Write a C program to Reverse a String Using Loop
#include <stdio.h>

int main() {
    char str[100], rev[100];
    int i, len = 0;

    printf("Enter a string: ");
    gets(str);

    while (str[len] != '\0') {
        len++;
    }

    for (i = 0; i < len; i++) {
        rev[i] = str[len - i - 1];
    }

    rev[i] = '\0';

    printf("Reversed string: %s\n", rev);

    return 0;
}
