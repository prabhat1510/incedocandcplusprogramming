#include <stdio.h>

int main() {
    int a,b;
    char op;

    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);
    printf("Enter operator(+,-,*,/): \n");
    scanf(" %c", &op);
    switch(op) {
        case '+':
            printf("%d + %d = %d\n", a, b, a+b);
            break;
        case '-':
            printf("%d - %d = %d\n", a, b, a-b);
            break;
        case '*':
            printf("%d * %d = %d\n", a, b, a*b);
            break;
        case '/':
            printf("%d / %d = %d\n", a, b, a/b);
            break;
        default:
            printf("Invalid operator!\n");
    }
return 0;
}