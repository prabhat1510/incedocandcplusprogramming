//1.	Create a student database using structures (store name, roll no, marks)
//2.	Save and retrieve student records from a file
//3.	Implement a phone book with file persistence
/**
 * 1. Create a structure of student and store data into file
 * 2. Add new student record in existing file
 * 3. Retrieve particular student record from file
 */
#include <stdio.h>
#include <stdlib.h>

struct Student {
    int roll;
    char name[30];
    float marks;
};

void saveStudent() {
    FILE *fp;
    struct Student s;

    fp = fopen("students.dat", "ab");  // append in binary mode
    if (fp == NULL) {
        printf("File could not be opened!\n");
        return;
    }

    printf("\nEnter Roll No: ");
    scanf("%d", &s.roll);

    printf("Enter Name: ");
    scanf("%s", s.name);

    printf("Enter Marks: ");
    scanf("%f", &s.marks);

    fwrite(&s, sizeof(s), 1, fp);
    fclose(fp);

    printf("Student record saved successfully!\n");
}

void readStudents() {
    FILE *fp;
    struct Student s;

    fp = fopen("students.dat", "rb");
    if (fp == NULL) {
        printf("\nNo records found!\n");
        return;
    }

    printf("\n--- Student Records ---\n");
    while (fread(&s, sizeof(s), 1, fp)) {
        printf("Roll No: %d\n", s.roll);
        printf("Name   : %s\n", s.name);
        printf("Marks : %.2f\n", s.marks);
        printf("------------------------\n");
    }

    fclose(fp);
}

int main() {
    int choice;

    while (1) {
        printf("\n===== Student Database Menu =====\n");
        printf("1. Save Student Record\n");
        printf("2. Read Student Records\n");
        printf("3. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                saveStudent();
                break;

            case 2:
                readStudents();
                break;

            case 3:
                printf("Exiting program...\n");
                exit(0);

            default:
                printf("Invalid choice! Try again.\n");
        }
    }

    return 0;
}
