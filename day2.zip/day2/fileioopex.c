/**
 * fopen() - Open or create a file
 * fclose() - Close an opened file
 * fprintf() - Write formatted data to a file
 * fscanf() - Read formatted data from a file
 * getc() - Read a character from a file
 * putc() - Write a character to a file
 * fgets() - Read a string from a file
 * fputs() - Write a string to a file
 * fwrite() - Write a fixed number of bytes to a file - binary data to a file
 * fread() - Read Binary Data from file
 * feof() - Test for end-of-file
 * File Modes:-
 * | Mode   | Meaning                                   |
| ------ | ----------------------------------------- |
| `"r"`  | Read (file must exist)                    |
| `"w"`  | Write (creates new / overwrites existing) |
| `"a"`  | Append (add data at end)                  |
| `"r+"` | Read & write                              |
| `"w+"` | Write & read                              |
| `"a+"` | Append & read                             |
| `"rb"` | Read in binary                            |
| `"wb"` | Write in binary                           |
| `"ab"` | Append in binary                          |

 * 
 */
#include <stdio.h>
int main()
{
    FILE *fp;
    //fp = fopen("D:\\ccppprojects\\abc.txt","r+");
    int age;
    char name[20];

    // Writing to file
    fp = fopen("student.txt", "w");
    if(fp==NULL)
    {
        printf("file does not exist");
    }
    else
    {
        printf("file opened successfully");
        fprintf(fp, "Name: Prabhat\nAge: 25\n");
    }
    fclose(fp);

     // Reading from file
    fp = fopen("student.txt", "r");
    fscanf(fp, "Name: %s\nAge: %d", name, &age);
    fclose(fp);

    printf("Name = %s\nAge = %d\n", name, age);

    fp = fopen("student.txt", "a");
    fprintf(fp, "\nCourse: C Programming");
    fclose(fp);

    return 0;
}