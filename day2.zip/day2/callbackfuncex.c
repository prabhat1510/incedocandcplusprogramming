//Example of call back function in C program
/**
 * void (*operation)(int, int) is a function pointer
 * add and subtract are passed as arguments
 * calculate() does not know which operation it will perform
 * It simply calls back the function via the pointer
 * 
 */
#include <stdio.h>

// Callback functions
void add(int a, int b) {
    printf("Addition = %d\n", a + b);
}

void subtract(int a, int b) {
    printf("Subtraction = %d\n", a - b);
}

// Function that accepts a callback
void calculate(int x, int y, void (*operation)(int, int)) {
    printf("Performing operation...\n");
    operation(x, y);   // Callback invocation
}


int main(){

    int a = 10, b = 5;

    // Passing functions as callbacks
    calculate(a, b, add);
    calculate(a, b, subtract);
    return 0;
}