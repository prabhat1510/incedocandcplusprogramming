/**
 * 1. Implement your own strlen(), strcpy(), strcat() functions
 * 2. Dynamic array: create an array of user-defined size at runtime
 * 3. Swap two numbers using pointers (call by reference)
 * 
 */
//1. Implement your own strlen(), strcpy(), strcat() functions

#include <stdio.h>

// Custom strlen()
int my_strlen(char str[]) {
    int len = 0;
    while (str[len] != '\0') {
        len++;
    }
    return len;
}

// Custom strcpy()
void my_strcpy(char dest[], char src[]) {
    int i = 0;
    while (src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';   // end of string
}

// Custom strcat()
void my_strcat(char dest[], char src[]) {
    int i = 0, j = 0;

    // Move i to end of dest string
    while (dest[i] != '\0') {
        i++;
    }

    // Append src to dest
    while (src[j] != '\0') {
        dest[i] = src[j];
        i++;
        j++;
    }
    dest[i] = '\0';
}

int main() {
    char s1[100] = "Hello";
    char s2[100] = "World";
    char s3[100];

    printf("Length of s1 = %d\n", my_strlen(s1));

    my_strcpy(s3, s1);
    printf("After my_strcpy, s3 = %s\n", s3);

    my_strcat(s1, s2);
    printf("After my_strcat, s1 = %s\n", s1);

    return 0;
}
