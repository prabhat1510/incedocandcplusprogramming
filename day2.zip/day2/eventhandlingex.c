#include <stdio.h>
// Callback functions (event handlers)
void onButtonClick() {
    printf("Event: Button Clicked!\n");
}

void onKeyPress() {
    printf("Event: Key Pressed!\n");
}

void onExit() {
    printf("Event: Exiting application...\n");
}

/**void handleEvent(char* event) {
    if (strcmp(event, "button_click") == 0) {
        onButtonClick();
    } else if (strcmp(event, "key_press") == 0) {
        onKeyPress();
    } else if (strcmp(event, "exit") == 0) {
        onExit();
    }
}*/

// Event dispatcher (accepts a callback)
void handleEvent(void (*eventHandler)()) {
    if (eventHandler != NULL) {
        eventHandler();   // Callback invocation
    }
}


int main(){
    int choice;
    printf("\n--- Event Menu ---\n");
    printf("1. Button Click\n");
    printf("2. Key Press\n");
    printf("3. Exit\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    switch(choice){
        case 1:
            handleEvent(onButtonClick);  // Passing callback
            break;
        case 2:
            handleEvent(onKeyPress);  // Passing callback
            break;
        case 3:
            handleEvent(onExit);  // Passing callback
            break;
        default:
            printf("Invalid Choice!");
    }
    return 0;
}