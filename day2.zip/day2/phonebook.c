//Add a new contact
//View all contacts
//Search a contact by name
//Exit

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Contact {
    char name[30];
    char phone[15];
};

void addContact() {
    FILE *fp;
    struct Contact c;

    fp = fopen("phonebook.dat", "ab");
    if (fp == NULL) {
        printf("Unable to open file!\n");
        return;
    }

    printf("\nEnter Name: ");
    scanf("%s", c.name);

    printf("Enter Phone Number: ");
    scanf("%s", c.phone);

    fwrite(&c, sizeof(c), 1, fp);
    fclose(fp);

    printf("Contact saved successfully!\n");
}

void viewContacts() {
    FILE *fp;
    struct Contact c;

    fp = fopen("phonebook.dat", "rb");
    if (fp == NULL) {
        printf("\nNo contacts found!\n");
        return;
    }

    printf("\n--- Phone Book ---\n");
    while (fread(&c, sizeof(c), 1, fp)) {
        printf("Name : %s\n", c.name);
        printf("Phone: %s\n", c.phone);
        printf("----------------------\n");
    }

    fclose(fp);
}

void searchContact() {
    FILE *fp;
    struct Contact c;
    char searchName[30];
    int found = 0;

    fp = fopen("phonebook.dat", "rb");
    if (fp == NULL) {
        printf("\nNo contacts found!\n");
        return;
    }

    printf("\nEnter name to search: ");
    scanf("%s", searchName);

    while (fread(&c, sizeof(c), 1, fp)) {
        if (strcmp(c.name, searchName) == 0) {
            printf("\nContact Found!\n");
            printf("Name : %s\n", c.name);
            printf("Phone: %s\n", c.phone);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("\nContact not found!\n");
    }

    fclose(fp);
}

int main() {
    int choice;

    while (1) {
        printf("\n===== Phone Book Menu =====\n");
        printf("1. Add Contact\n");
        printf("2. View Contacts\n");
        printf("3. Search Contact\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addContact();
                break;

            case 2:
                viewContacts();
                break;

            case 3:
                searchContact();
                break;

            case 4:
                printf("Exiting Phone Book...\n");
                exit(0);

            default:
                printf("Invalid choice! Try again.\n");
        }
    }

    return 0;
}
