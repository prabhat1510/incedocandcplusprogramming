/**#include <stdio.h>
int main()
{
    int x=10;
    int *p;
    p=&x;
    printf("%d\n",*p);
    *p=20;
    printf("%d\n",x);
    return 0;
}*/

//Declaration, Dereferencing, Address-of Operator
#include <stdio.h>
int main() {
    int x = 10;
    int *p = &x;   // p stores the address of x
    /**
     * x-> 10
     * p-> address of x 0x100F
     * *p->10
     * 
     */
    printf("Value of x: %d\n", x);
    printf("Address of x: %p\n", &x);
    printf("Value stored in p (address of x): %p\n", p);
    printf("Value at address p points to: %d\n", *p);

    return 0;
}
