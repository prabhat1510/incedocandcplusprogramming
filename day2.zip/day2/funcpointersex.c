//A function pointer stores the address of a function.
#include <stdio.h>

int add(int a, int b){
    return a+b;
}

int main(){
    int (*fp)(int,int) = &add; //function pointer
    //fp=add;
    int result = fp(10,20);
    printf("%d\n", result);
    
    printf("%d\n",(*fp)(10,20));
    return 0;
}
