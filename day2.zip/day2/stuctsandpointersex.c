#include <stdio.h>
#include <stdlib.h>
/**
 * In C, an array of characters is not a pointer itself, but the name of the array acts 
 * as a constant pointer to the address of its first element. This behavior is known 
 * as "array decay" and allows arrays to be used with pointer notation in most 
 * expressions, particularly when passed to functions. 
 * char arr[]="Hello";
 * char *p="hello";
 */
// Structure definition
struct Student {
    int roll;
    char name[30];
    float marks;
};
/**
int main(){
    struct Student s1;// structure variable
    struct Student *ptr; //pointer to structure
    ptr = &s1;           // pointer stores address of s1

    //Input using pointer
    printf("Enter roll number: ");
    scanf("%d", &ptr->roll);

    printf("Enter name: ");
    scanf("%s", ptr->name);

    printf("Enter marks: ");
    scanf("%f", &ptr->marks);
    //Output using pointer
    printf("\nRoll no: %d\nName: %s\nMarks: %.2f\n", ptr->roll, ptr->name, ptr->marks);
    return 0;
}
     */

int main(){
    struct Student *s;// Pointer to structure
    // Dynamic memory allocation for one Student
    s = (struct Student *)malloc(sizeof(struct Student));

    // Input using pointer
    printf("Enter Roll No: ");
    scanf("%d", &s->roll);

    printf("Enter Name: ");
    scanf("%s", s->name);

    printf("Enter Marks: ");
    scanf("%f", &s->marks);

    //Output using structure variable
    printf("\nRoll no: %d\nName: %s\nMarks: %.2f\n", s->roll, s->name, s->marks);
    free(s);
    return 0;
}
