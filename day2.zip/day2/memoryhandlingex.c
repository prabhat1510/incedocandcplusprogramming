/**
 * In a C program, memory is handled in a very explicit and structured way. 
 * Unlike higher-level languages, C gives you direct control over memory, 
 * which is powerful but dangerous if misused.
 * A running C program’s memory is divided into five main regions:
 *  
+----------------------+
|   Command Line Args  |
+----------------------+
|        Stack         |  ← Function calls, local variables
|----------------------|
|        Heap          |  ← Dynamic memory (malloc, calloc)
|----------------------|
|   Uninitialized Data |  ← Global/static (BSS)
|----------------------|
|    Initialized Data  |  ← Global/static with values
|----------------------|
|        Code          |  ← Program instructions
+----------------------+
1. Code or text when compiled using the compiler is stored in the code section
Contains the compiled machine instructions.


int add(int a, int b) {
    return a + b;
}

2. Initialized Data Segment
Global/static variables with initial values.
int global_var = 10;     // Initialized data segment
static int static_var = 20;  // Initialized data segment

In memory stored as :
globla_var=10
static_var=20

3. Uninitialized or BSS (Block Started by Symbol)
Global/static variables without initial values.

int count;  // BSS segment
static int total;  // BSS segment
Automatically initialized to 0 

4. Heap
Dynamic memory allocation happens here.
Memory is allocated and deallocated manually using functions like malloc(), calloc(), realloc(), and free().

int *ptr = (int*)malloc(sizeof(int) * 10);  // Allocated on heap
//In memory  --- Stack: p ----> Heap:[?] [?] [?] [?] [?] [?][?] [?] [?][?]
free(ptr);  // Deallocated from heap

5. Stack
Local variables and function call management.
Each function call creates a new stack frame containing local variables and return addresses.

void someFunction() {
    int local_var = 5;  // Stored on stack
    // ...
}

In memory :
func() called
    local_var=5  (pushed onto the stack)
func() returns
    local_var is removed from the stack
 */