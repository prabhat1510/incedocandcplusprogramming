//In c program Strings are character arrays end with '\0'
#include <stdio.h>
int main() {
    char str[]="Hello";
    printf("%s",str);
    char *p=str;
    printf("\n%s", p);
    printf("\n");
    /**
     * H e l l o \0
     * ^
     * p    
     */
    while(*p != '\0')
    {
        printf("%c", *p);
        p++;
    }
    return 0;
}