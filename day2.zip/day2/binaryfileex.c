//Binary File Example – Using fwrite() and fread()
/**#include<stdio.h>
#include<conio.h>
struct emp
    {
    int empno;
    char name[10];
    float sal;
    };

void main()
{
    struct emp e1={101,"ASHISH",3456.50};
    struct emp e2;
    FILE *fp;
    //clrscr();
    fp=fopen("EMP.DAT","wb");

    fwrite(&e1,sizeof(e1),1,fp);

    fclose(fp);

    fp=fopen("EMP.DAT","rb");
    fread(&e2,sizeof(e2),1,fp);

    printf("\n%d %s %.2f",e2.empno,e2.name,e2.sal);
    fclose(fp);
    getch();
}**/

#include <stdio.h>

struct Student {
    int roll;
    float marks;
};

int main() {
    FILE *fp;
    struct Student s = {101, 88.5};
    struct Student r;

    // Write binary
    fp = fopen("data.bin", "wb");
    fwrite(&s, sizeof(s), 1, fp);
    fclose(fp);

    // Read binary
    fp = fopen("data.bin", "rb");
    fread(&r, sizeof(r), 1, fp);
    fclose(fp);

    printf("Roll = %d, Marks = %.2f\n", r.roll, r.marks);

    return 0;
}
