#include <stdio.h>

// Inner structure
struct Address {
    char city[20];
    char state[20];
    int pincode;
};

// Outer structure
struct Student {
    int roll;
    char name[30];
    struct Address addr;   // Nested structure
};

int main() {
    struct Student s1 = {1, "Anil", {"Delhi", "Delhi", 110001}};

      // Output
    printf("\n--- Student Details ---\n");
    printf("Roll No: %d\n", s1.roll);
    printf("Name: %s\n", s1.name);
    printf("City: %s\n", s1.addr.city);
    printf("State: %s\n", s1.addr.state);
    printf("Pincode: %d\n", s1.addr.pincode);
    
    printf("Roll: %d\n", s1.roll);
    printf("Name: %s\n", s1.name);
    printf("City: %s\n", s1.addr.city);
    printf("State: %s\n", s1.addr.state);
    printf("Pincode: %d\n", s1.addr.pincode);
    return 0;
}