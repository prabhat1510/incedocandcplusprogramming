//Array name itself is a pointer to the first element
#include <stdio.h>
int main() {
    int arr[3]={5,10,15};
    printf("%u\n",arr);
    printf("%u\n", arr+1);
    printf("%u\n", *arr);
    printf("%u\n", arr[0]);
    printf("%u\n", *(arr+1));
    printf("%u\n",arr[1]);
    return 0;
}