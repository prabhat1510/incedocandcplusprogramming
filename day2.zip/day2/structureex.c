#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    struct Student
    {
        int rollno;
        char name[20];
        float marks;
    };
    struct Student s1={1,"ABCD",85.5};
    //struct student *ptr=&s1;
    struct Student s2;
    s2.rollno=2;
    s2.marks=90.5;
    strcpy(
        s2.name,"Raj"
    );
    printf("%d %s %f",s1.rollno,s1.name,s1.marks);
    printf("%d %s %f", s2.rollno, s2.name, s2.marks);
    //Array of Structures
    struct Student s[3];
    s[0]=(struct Student){1,"Raju",85.5};
    s[1]=(struct Student){2,"Rakesh",95.5};
    s[2]=(struct Student){3,"Mohit",75.5};
    for(int i=0;i<3;i++)
    {
        printf("\n%d %s %f", s[i].rollno, s[i].name, s[i].marks);
    }
    return 0;
}