#include <iostream>
using namespace std;

int main() {
    cout << "Hello, VS Code!" << endl;
    return 0;
}
