#include <iostream>
using namespace std;

class Box{
    int length;
    public:
        Box(){
            length=0;
            cout<<"Default constructor called"<<endl;
        }
    public:
        Box(int l){
            length=l;
            cout<<"Parameterized constructor called"<<endl;
        }
    
        Box(Box &b){
            length=b.length;
            cout<<"Copy constructor called"<<endl;
        }
    void show(){
            cout<<length<<endl;
        }
    
};

int main(){
    Box b1;//Default constructor
    cout<<"b1 object created "<<endl;
    b1.show();
    Box b2(10);
    b2.show();
   
    Box b3 = b2;
    b3.show();
  
    return 0;
}
