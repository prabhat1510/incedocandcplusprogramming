#include <stdio.h>
#define MAX 10

int queue[MAX];
int front = -1, rear = -1;

void enqueue(int ticketNo){
    if(rear == MAX-1){
        printf("Queue is full");
        return ;
    }
    if(front == -1 && rear == -1){
        front = rear = 0;
        queue[rear] = ticketNo;
    }else{
        rear++;
        queue[rear] = ticketNo;
    }
}

void dequeue(){
    if(front == -1 && rear == -1){
        printf("Queue is empty");
        return ;
    }
    printf("Ticket no %d is cancelled", queue[front]);
    front++;
    if(front > rear){
        front = rear = -1;
    }
   
}

void display(){
        if(front == -1 && rear == -1){
            printf("Queue is empty");
            return ;
        }
        printf("Queue elements are: ");
        for(int i=front; i<=rear; i++){
            printf("%d ", queue[i]);
        }
}

int main(){
    int choice, ticket=1001;
    do{
        printf("\n1. Add a ticket\n2. Cancel a ticket\n3. Display queue\n4. Exit\nEnter your choice: ");
        scanf("%d", &choice);
        switch(choice){
            case 1: enqueue(ticket++);
                    break;
            case 2: dequeue();
                    break;
            case 3: display();
                    break;
            case 4: break;
            default: printf("Invalid choice");
        }
    }while(choice != 4);
    return 0;
}