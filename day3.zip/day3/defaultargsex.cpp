#include <iostream>
using namespace std;

void func(int a, int b = 10, int c = 20){
    cout << a << " " << b << " " << c << endl;
}

void greet(string name="Prabhat"){
    cout<<"Hello, "<<name <<endl;
}
int main(){
    func(15,11,5);//Default argument will be overriden
    func(10);
    greet(); //Default value is assigned to name variable
    greet("Rahul");
    return 0;
}