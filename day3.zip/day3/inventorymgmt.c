#include <stdio.h>
#include <stdlib.h>

struct Item {
    int id;
    char name[30];
    int qty;
    float price;
};


void addItem() {
    FILE *fp = fopen("inventory.dat", "ab");
    struct Item it;

    printf("Enter ID: ");
    scanf("%d", &it.id);
    printf("Enter Name: ");
    scanf("%s", it.name);
    printf("Enter Quantity: ");
    scanf("%d", &it.qty);
    printf("Enter Price: ");
    scanf("%f", &it.price);

    fwrite(&it, sizeof(it), 1, fp);
    fclose(fp);

    printf("Item added successfully.\n");
}

void viewItems() {
    FILE *fp = fopen("inventory.dat", "rb");
    struct Item it;

    if (!fp) {
        printf("No records found.\n");
        return;
    }

    printf("\nID\tName\tQty\tPrice\n");
    while (fread(&it, sizeof(it), 1, fp)) {
        printf("%d\t%s\t%d\t%.2f\n", it.id, it.name, it.qty, it.price);
    }
    fclose(fp);
}

void updateItem() {
    FILE *fp = fopen("inventory.dat", "rb+");
    struct Item it;
    int searchId, found = 0;

    if (!fp) {
        printf("No records found.\n");
        return;
    }

    printf("Enter Item ID to update: ");
    scanf("%d", &searchId);

    while (fread(&it, sizeof(it), 1, fp)) {
        if (it.id == searchId) {
            printf("Current Details:\n");
            printf("ID: %d\nName: %s\nQty: %d\nPrice: %.2f\n",
                   it.id, it.name, it.qty, it.price);

            printf("\nEnter New Name: ");
            scanf("%s", it.name);
            printf("Enter New Quantity: ");
            scanf("%d", &it.qty);
            printf("Enter New Price: ");
            scanf("%f", &it.price);

            /* Move file pointer back by one record */
            fseek(fp, -(long)sizeof(struct Item), SEEK_CUR);

            fwrite(&it, sizeof(it), 1, fp);

            printf("Item updated successfully.\n");
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Item with ID %d not found.\n", searchId);
    }

    fclose(fp);
}



int main() {
    int choice;

    do {
        printf("\n--- Inventory Management ---\n");
        printf("1. Add Item\n2. View Items\n3. Update Items\n4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: addItem(); break;
            case 2: viewItems(); break;
            case 3: updateItem();break;
            case 4: printf("Exiting...\n"); break;
            default: printf("Invalid choice!\n");
        }
    } while (choice != 4);

    return 0;
}