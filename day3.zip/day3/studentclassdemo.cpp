#include <iostream>
using namespace std;
//Real world entity or object student is defined using the class Student
class Student{
    //private int roll;
    private:
        int roll;
    public:
        float marks;
    public:
        string name;

    void setRoll(int roll){
            roll=roll;
    }
    void display(){
        cout<< "Name: "<<name<<" Roll: "<<roll<<" Marks: "<<marks<<endl;
    }

};

int main(){
    Student s1; // Reference variable s1
    s1.name="Amit";
    s1.marks=98;
    //s1.roll=111;
    s1.setRoll(101);
    s1.display();
    return 0;
}