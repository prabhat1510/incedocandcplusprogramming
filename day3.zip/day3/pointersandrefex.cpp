#include <iostream>
using namespace std;

int main() {
   int x=10;
   int *p=&x;
   int &r=x;

   cout<<x<<" "<<*p<<" "<<r<<endl;
   r=20;
   cout<<x<<" "<<*p<<" "<<r<<endl;
    return 0;
}
