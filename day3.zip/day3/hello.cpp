#include <iostream>
//using namespace std;

int main() {
    int age;
    std::cout << "Enter your age: ";
    std::cin >> age;

    std::cout << "You entered: " << age << std::endl;
    return 0;
}
