#include <iostream>
using namespace std;

class Demo{
    int x,y;
    public:
    Demo(int a, int b){
        x=a;y=b;
        cout<<"constructor is called"<<endl;
    }
    ~Demo(){
        cout<<"destructor is called"<<endl;
    }
};

int main(){
    Demo d1(10,20);
    cout<<"Inside main"<<endl;
    return 0;
}