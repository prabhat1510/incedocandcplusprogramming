#include <iostream>
using namespace std;

int add(int a, int b)
{
    return a+b;
}
float add(float a, float b)
{
    return a+b;
}

int add(int a, int b, int c)
{
    return a+b+c;
}

int add(int a){
    return a+18;
}

int main(){
    cout<<add(3,4)<<endl;
    cout<<add(3.5f,4.5f)<<endl;
    cout<<add(3, 4, 5)<<endl;
    cout<<add(3)<<endl;
    return 0;
}