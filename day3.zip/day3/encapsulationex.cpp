//Encapsulation = Data Hiding + Controlled Access
/**In C++, this is achieved using access specifiers:
    private – data is hidden from outside the class
    public – accessible from outside
    protected – accessible in derived classes
*/

#include <iostream>
using namespace std;

class BankAccount {

    private:
        double balance;   // Hidden data

    public:
        // Constructor
        BankAccount(double initialBalance) {
            if (initialBalance >= 0)
                balance = initialBalance;
            else
                balance = 0;
        }

        // Getter method
        double getBalance() {
            return balance;
        }
        //Setter method
        void setBalance(double newBalance)
        {
            balance = newBalance;
        }

         // Public method to deposit money
        void deposit(double amount) {
            if (amount > 0)
                balance += amount;
            else
                cout << "Invalid deposit amount\n";
        }

        // Public method to withdraw money
        void withdraw(double amount) {
            if (amount > 0 && amount <= balance)
                balance -= amount;
            else
                cout << "Invalid withdrawal\n";
        }
        
    

};

int main() {
    BankAccount acc(1000);   // Create object

    acc.deposit(500);
    acc.withdraw(300);

    cout << "Current Balance: " << acc.getBalance() << endl;
    acc.setBalance(100000);
    cout << "Current Balance: " << acc.getBalance() << endl;
   //acc.balance = 100000;  //ERROR: balance is private

    return 0;
}